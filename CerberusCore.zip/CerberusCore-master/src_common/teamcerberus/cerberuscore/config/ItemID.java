package teamcerberus.cerberuscore.config;

public @interface ItemID {}
