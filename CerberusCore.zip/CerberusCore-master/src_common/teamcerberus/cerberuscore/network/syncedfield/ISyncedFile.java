package teamcerberus.cerberuscore.network.syncedfield;

public interface ISyncedFile {
	public String instanceIdent();
}
